#CodeKit

[![Build Status](https://travis-ci.org/boxen/puppet-codekit.png)](https://travis-ci.org/boxen/puppet-codekit)

Installs [CodeKit](http://incident57.com/codekit/).

## Usage

```puppet
include codekit
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
