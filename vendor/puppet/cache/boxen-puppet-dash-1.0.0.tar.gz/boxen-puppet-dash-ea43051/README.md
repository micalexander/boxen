# Dash Puppet Module for Boxen

Install [Dash](http://kapeli.com/dash), an easy way to share files
and folders on Mac OS X.

## Usage

```puppet
include dash
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.

