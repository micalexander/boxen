# XtraFinder Puppet Module for Boxen [![Build Status](https://travis-ci.org/boxen/puppet-xtrafinder.png)](https://travis-ci.org/boxen/puppet-xtrafinder)

Install [XtraFinder](http://www.trankynam.com/xtrafinder/), a tool that adds Tabs and features to Mac Finder.

## Usage

```puppet
include xtrafinder
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
