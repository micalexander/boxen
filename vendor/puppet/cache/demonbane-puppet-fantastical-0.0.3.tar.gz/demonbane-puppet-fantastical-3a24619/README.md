# Fantastical Puppet Module for Boxen

Install [Fantastical](http://flexibits.com/fantastical), a calendar app for Mac OS X.

## Usage

```puppet
include fantastical
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
