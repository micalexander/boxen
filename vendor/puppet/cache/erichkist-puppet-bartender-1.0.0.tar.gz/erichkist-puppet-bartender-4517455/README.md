# Bartender Puppet Module for Boxen

Install [Bartender](http://www.macbartender.com/), a pretty good app
for organize your menu bar apps.

## Usage

```puppet
include bartender
```

## Required Puppet Modules

* `boxen`
* `stdlib`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
