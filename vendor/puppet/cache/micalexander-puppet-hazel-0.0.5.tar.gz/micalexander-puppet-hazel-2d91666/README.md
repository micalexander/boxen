# Hazel Puppet Module for Boxen

Install Hazel prefPane

## Usage

```puppet
include hazel
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
