# Adobe Creative Cloud Plugin Puppet Module for Boxen

## Usage

```puppet
include adobe_creative_cloud
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.
