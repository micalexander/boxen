# CleanMyMac2 Module for Boxen

Install [CleanMyMac 2](http://macpaw.com/cleanmymac), application for keeping your Mac clean, organized, and free of files that slow it down.

## Usage

```puppet
include clean_my_mac2
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
