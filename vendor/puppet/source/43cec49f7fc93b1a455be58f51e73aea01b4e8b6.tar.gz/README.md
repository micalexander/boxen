# HyperDock Puppet Module for Boxen

Install [HyperDock](http://hyperdock.bahoom.com/), a commercial dock and window management utility.

## Usage

```puppet
include hyperdock
```

## Required Puppet Modules

* `boxen`
